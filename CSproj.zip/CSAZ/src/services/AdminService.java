package services;

import db.DBConnection;
import services.EventService.CreatedEvent;
import exceptions.MessageBox;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;


public class AdminService {

    public static int getUsersCount() {
        int count = 0;
        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement("SELECT COUNT(*) FROM users")) {
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                count = rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return count;
    }

    public static int getEventsCount() {
        int count = 0;
        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement("SELECT COUNT(*) FROM events")) {
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                count = rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return count;
    }

    public static int getRegistrationsCount() {
        int count = 0;
        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement("SELECT COUNT(*) FROM registrations")) {
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                count = rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return count;
    }

    public static int getCategoriesCount() {
        int count = 0;
        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement("SELECT COUNT(*) FROM categories")) {
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                count = rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return count;
    }

    public static int getOrganizersCount() {
        int count = 0;
        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement("SELECT COUNT(*) FROM users WHERE role = 'organizer'")) {
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                count = rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return count;
    }

    public static int getAttendeesCount() {
        int count = 0;
        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement("SELECT COUNT(*) FROM users WHERE role = 'attendee'")) {
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                count = rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return count;
    }

    public static List<CreatedEvent> getAllCreatedEvents() {
        List<CreatedEvent> list = new ArrayList<>();
        String sql = "SELECT event_id, event_name, location, date, total_seats FROM events";

        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                list.add(new CreatedEvent(
                        rs.getInt("event_id"),
                        rs.getString("event_name"),
                        rs.getString("location"),
                        rs.getString("date"),
                        rs.getInt("total_seats")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

   /* public static boolean deleteEventById(int eventId) {
        String deleteRegistrations = "DELETE FROM registrations WHERE event_id = ?";
        String deleteNotifications = "DELETE FROM notifications WHERE event_id = ?";
        String deleteEvent = "DELETE FROM events WHERE event_id = ?";

        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);

            try (PreparedStatement stmt1 = conn.prepareStatement(deleteRegistrations);
                    PreparedStatement stmt2 = conn.prepareStatement(deleteNotifications);
                    PreparedStatement stmt3 = conn.prepareStatement(deleteEvent)) {

                stmt1.setInt(1, eventId);
                stmt1.executeUpdate();

                stmt2.setInt(1, eventId);
                stmt2.executeUpdate();

                stmt3.setInt(1, eventId);
                int rows = stmt3.executeUpdate();

                conn.commit();
                return rows > 0;
            } catch (SQLException e) {
                conn.rollback();
                e.printStackTrace();
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    */
    public static boolean deleteEventById(int eventId) {
    String sqlNotifications = "DELETE FROM notifications WHERE event_id = ?";
    String sqlRegistrations = "DELETE FROM registrations WHERE event_id = ?";
    String sqlEvent = "DELETE FROM events WHERE event_id = ?";

    try (Connection conn = DBConnection.getConnection()) {
        conn.setAutoCommit(false);

        try (PreparedStatement stmtN = conn.prepareStatement(sqlNotifications);
             PreparedStatement stmtR = conn.prepareStatement(sqlRegistrations);
             PreparedStatement stmtE = conn.prepareStatement(sqlEvent)) {

            stmtN.setInt(1, eventId);
            stmtN.executeUpdate();

            stmtR.setInt(1, eventId);
            stmtR.executeUpdate();

            stmtE.setInt(1, eventId);
            int rows = stmtE.executeUpdate();

            conn.commit();
            return rows > 0;
        } catch (SQLException e) {
            conn.rollback();
            exceptions.MessageBox.showError("Error deleting event: " + e.getMessage());
            return false;
        } finally {
            conn.setAutoCommit(true);
        }
    } catch (SQLException e) {
        exceptions.MessageBox.showError("Error deleting event: " + e.getMessage());
        return false;
    }
}
    
    
    public static boolean updateUser(int userId, String username, String email, String role, String gender) {
    String sql = "UPDATE users " +
                 "SET username = ?, email = ?, role = ?, gender = ?, updated_at = NOW()" +
                 "WHERE user_id = ?";

    try (Connection conn = DBConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        stmt.setString(1, username);
        stmt.setString(2, email);
        stmt.setString(3, role);
        stmt.setString(4, gender);
        stmt.setInt(5, userId);

        int rows = stmt.executeUpdate();
        return rows > 0;  // لو مافي ولا صف اتعدل ترجع false

    } catch (SQLException e) {
        MessageBox.showError("Error updating user: " + e.getMessage());
        return false;
    }
}
  public static boolean deleteUser(int userId) {

    String deleteNotifications = "DELETE FROM notifications WHERE user_id = ?";
    String deleteRegistrations = "DELETE FROM registrations WHERE attendee_id = ?";
    String deleteEvents = "DELETE FROM events WHERE organizer_id = ?";
    String deleteUser = "DELETE FROM users WHERE user_id = ?";

    try (Connection conn = DBConnection.getConnection()) {

        conn.setAutoCommit(false);

        PreparedStatement stmt1 = conn.prepareStatement(deleteNotifications);
        stmt1.setInt(1, userId);
        stmt1.executeUpdate();

        PreparedStatement stmt2 = conn.prepareStatement(deleteRegistrations);
        stmt2.setInt(1, userId);
        stmt2.executeUpdate();

        PreparedStatement stmt3 = conn.prepareStatement(deleteEvents);
        stmt3.setInt(1, userId);
        stmt3.executeUpdate();

        PreparedStatement stmt4 = conn.prepareStatement(deleteUser);
        stmt4.setInt(1, userId);
        int rows = stmt4.executeUpdate();

        conn.commit();
        return rows > 0;

    } catch (SQLException e) {
        MessageBox.showError("Error deleting user: " + e.getMessage());
        return false;
    }
}
  
  public static Map<Integer, Integer> getRegistrationsPerEvent() {
    Map<Integer, Integer> map = new HashMap<>();

    String sql = "SELECT event_id, COUNT(*) AS registrations " +
                 "FROM registrations " +
                 "GROUP BY event_id";

    try (Connection conn = DBConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql);
         ResultSet rs = stmt.executeQuery()) {

        while (rs.next()) {
            int eventId = rs.getInt("event_id");
            int count   = rs.getInt("registrations");
            map.put(eventId, count);
        }

    } catch (SQLException e) {
        exceptions.MessageBox.showError(
                "Error loading registrations per event: " + e.getMessage()
        );
    }

    return map;
}


}
