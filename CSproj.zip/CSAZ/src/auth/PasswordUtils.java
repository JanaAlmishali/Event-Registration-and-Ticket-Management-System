package auth;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

public class PasswordUtils {

    private static final SecureRandom RANDOM = new SecureRandom();

    // 🔐 لإنشاء كلمة مرور مشفّرة (مع salt)
    public static String hashPassword(String password) {
        if (password == null) {
            throw new IllegalArgumentException("Password cannot be null");
        }

        // 1) نولّد salt عشوائي
        byte[] salt = new byte[16];
        RANDOM.nextBytes(salt);

        // 2) نحسب الـ hash لكلمة المرور + salt
        String saltB64 = Base64.getEncoder().encodeToString(salt);
        String hashB64 = hashWithSalt(password, salt);

        // 3) نخزنهم بصيغة:  salt:hash
        return saltB64 + ":" + hashB64;
    }

    // ✅ للتحقق من كلمة المرور المدخلة مقارنةً بالمحفوظة في الداتا بيس
    public static boolean verifyPassword(String password, String stored) {
        if (password == null || stored == null) {
            return false;
        }

        // لازم تكون الصيغة "salt:hash"
        String[] parts = stored.split(":");
        if (parts.length != 2) {
            // شكل غير متوقع (مثلاً بيانات قديمة بدون hashing)
            return false;
        }

        String saltB64 = parts[0];
        String storedHashB64 = parts[1];

        byte[] salt;
        try {
            salt = Base64.getDecoder().decode(saltB64);
        } catch (IllegalArgumentException e) {
            return false;
        }

        String calculatedHashB64 = hashWithSalt(password, salt);

        // مقارنة آمنة
        byte[] storedHash = Base64.getDecoder().decode(storedHashB64);
        byte[] calcHash = Base64.getDecoder().decode(calculatedHashB64);

        return slowEquals(storedHash, calcHash);
    }

    // ================== Helpers ==================

    // تحسب SHA-256(password + salt)
    private static String hashWithSalt(String password, byte[] salt) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(salt); // نضيف الـ salt
            byte[] hashed = md.digest(password.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(hashed);
        } catch (NoSuchAlgorithmException e) {
            // مستحيل تقريباً تصير في JVM عادية
            throw new RuntimeException("SHA-256 algorithm not available", e);
        }
    }

    private static boolean slowEquals(byte[] a, byte[] b) {
        if (a == null || b == null) return false;
        if (a.length != b.length) return false;

        int diff = 0;
        for (int i = 0; i < a.length; i++) {
            diff |= a[i] ^ b[i];
        }
        return diff == 0;
    }
}
