package auth;

import db.DBConnection;
import java.sql.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import exceptions.AuthException;

//Class for the Register JFrame
public class Register extends JFrame implements ActionListener {
    private JTextField User_Name_Field, Email_Field;
    private JPasswordField Password_Field;
    private JLabel User_Name_Label, Password_Label, Email_Label, Tit;
    private JButton Register_Button, Return_Button;

    // NEW: gender & role
    private JLabel Gender_Label, Role_Label;
    private JComboBox<String> Gender_Box, Role_Box;

    public Register() {
        setTitle("Register");
        setSize(450, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center on screen

        // Components Definition
        User_Name_Field = new JTextField();
        User_Name_Label = new JLabel("User Name");
        Password_Label = new JLabel("Password");
        Password_Field = new JPasswordField();
        Register_Button = new JButton("Register");
        Email_Field = new JTextField();
        Email_Label = new JLabel("Email");
        Tit = new JLabel("Create an Account");
        Return_Button = new JButton("Go Back");

        // NEW: gender & role components
        Gender_Label = new JLabel("Gender");
        Gender_Box = new JComboBox<>(new String[] { "Select Gender", "Male", "Female" });

        Role_Label = new JLabel("Role");
        Role_Box = new JComboBox<>(new String[] { "Select Role", "attendee", "organizer" });

        // Component Modifications(Design)
        User_Name_Label.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        User_Name_Label.setBounds(70, 120, 100, 30);
        User_Name_Field.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        User_Name_Field.setBounds(70, 150, 300, 35);
        User_Name_Field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 2, 0, Color.GRAY),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)));

        Password_Label.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        Password_Label.setBounds(70, 200, 100, 30);
        Password_Field.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        Password_Field.setBounds(70, 230, 300, 35);
        Password_Field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 2, 0, Color.GRAY),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)));

        Email_Label.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        Email_Label.setBounds(70, 280, 100, 30);
        Email_Field.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        Email_Field.setBounds(70, 310, 300, 35);
        Email_Field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 2, 0, Color.GRAY),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)));

        // NEW: gender
        Gender_Label.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        Gender_Label.setBounds(70, 360, 100, 30);
        Gender_Box.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        Gender_Box.setBounds(70, 390, 300, 30);

        // NEW: role
        Role_Label.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        Role_Label.setBounds(70, 430, 100, 30);
        Role_Box.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        Role_Box.setBounds(70, 460, 300, 30);

        Register_Button.setFont(new Font("Segoe UI", Font.BOLD, 16));
        Register_Button.setBounds(70, 500, 300, 45);
        Register_Button.setBorder(null);
        Register_Button.setBackground(Color.GRAY);
        Register_Button.setForeground(Color.white);

        Return_Button.setFont(new Font("Segoe UI", Font.BOLD, 16));
        Return_Button.setBounds(20, 550, 100, 35);
        Return_Button.setBorder(null);
        Return_Button.setBackground(Color.gray);
        Return_Button.setForeground(Color.white);

        Tit.setFont(new Font("Segoe UI", Font.BOLD, 23));
        Tit.setBounds(120, 40, 200, 40); // x, y, width, height

        // Register Panel
        JPanel p1 = (JPanel) this.getContentPane();
        p1.setLayout(null);
        p1.setBackground(Color.white);
        p1.add(Tit);
        p1.add(User_Name_Label);
        p1.add(User_Name_Field);
        p1.add(Password_Label);
        p1.add(Password_Field);
        p1.add(Email_Field);
        p1.add(Email_Label);

        // NEW: add gender & role
        p1.add(Gender_Label);
        p1.add(Gender_Box);
        p1.add(Role_Label);
        p1.add(Role_Box);

        p1.add(Register_Button);
        p1.add(Return_Button);
        Return_Button.addActionListener(this);
        Register_Button.addActionListener(this);
    }

    public void actionPerformed(ActionEvent e) {
        Login log;
        if (e.getSource() == Return_Button) {// returns to previous panel
            this.setVisible(false);
            log = new Login();
            log.setVisible(true);
        }

        // this code is using real database
        if (e.getSource() == Register_Button) {
            String User_Name, Email;
            try {
                Email = Email_Field.getText().trim();
                User_Name = User_Name_Field.getText().trim();
                char[] pwd = Password_Field.getPassword();
                String password = new String(pwd);

                String gender = (String) Gender_Box.getSelectedItem();
                String role = (String) Role_Box.getSelectedItem();

                if (User_Name.isEmpty())
                    throw new AuthException("Enter User Name");
                if (password.isEmpty())
                    throw new AuthException("Enter Password");
                if (Email.isEmpty())
                    throw new AuthException("Enter Email");
                if (!Email.matches("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$")) {
                    throw new AuthException("Enter a valid email address");
                }
                if (Gender_Box.getSelectedIndex() == 0)
                    throw new AuthException("Select Gender");
                if (Role_Box.getSelectedIndex() == 0)
                    throw new AuthException("Select Role");

                // ✅ هنا نعمل hashing للباسورد
                String hashedPassword = PasswordUtils.hashPassword(password);

                Connection conn = DBConnection.getConnection();
                String sql = "INSERT INTO users (username, email, password, role, gender) VALUES (?, ?, ?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, User_Name);
                stmt.setString(2, Email);
                stmt.setString(3, hashedPassword); // ⬅️ استخدمنا الهاش بدل الباسورد
                stmt.setString(4, role);
                stmt.setString(5, gender);
                stmt.executeUpdate();
                stmt.close();
                conn.close();

                JOptionPane.showMessageDialog(null,
                        "Welcome: " + User_Name,
                        "Success", JOptionPane.INFORMATION_MESSAGE);

                this.setVisible(false);
                new Login().setVisible(true);

            } catch (AuthException e1) {
                JOptionPane.showMessageDialog(null, e1.getMessage(), "Error",
                        JOptionPane.ERROR_MESSAGE);
            } catch (SQLException e2) {
                JOptionPane.showMessageDialog(null, "Database Error: " + e2.getMessage(), "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}