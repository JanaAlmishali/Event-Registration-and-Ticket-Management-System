package auth;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Map;


import db.DBConnection;
import services.AdminService;

public class EventsPanel extends JPanel {

    private JTable eventsTable;
    private DefaultTableModel tableModel;

    public EventsPanel() {
        setPreferredSize(new Dimension(1200, 700));
        setLayout(new BorderLayout());

        // عنوان الصفحة
        JLabel titleLabel = new JLabel("Events Management", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(15, 0, 15, 0));
        add(titleLabel, BorderLayout.NORTH);

        // الأعمدة (مع Action في الأخير)
        String[] columnNames = {
                "ID",            // مخفي
                "Name",
                "Date",
                "Location",
                "Description",
                "Total Seats",
                "Registrations",   // NEW
                "Most attended",   // NEW
                "Availability",
                "Action"           // Delete button
        };

        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                // ولا عمود قابل للتعديل، حتى الـ Action
                // الضغط نعالجه بـ MouseListener
                return false;
            }
        };

        eventsTable = new JTable(tableModel);
        eventsTable.setRowHeight(60);
        eventsTable.setFont(new Font("Arial", Font.PLAIN, 14));
        eventsTable.setFillsViewportHeight(true);
        eventsTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

        // الهيدر
        JTableHeader header = eventsTable.getTableHeader();
        header.setFont(new Font("Arial", Font.BOLD, 14));
        header.setBackground(new Color(100, 100, 100));
        header.setForeground(Color.WHITE);
        header.setPreferredSize(new Dimension(header.getWidth(), 35));

        // سنتر لكل الأعمدة ما عدا الـ Description
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);

        // نطبّق بعد ما نحمل البيانات (بس مافيه ضرر هنا)
        eventsTable.setDefaultRenderer(Object.class, centerRenderer);

        // Renderer مخصص للوصف (multi-line)
        eventsTable.getColumnModel().getColumn(4).setCellRenderer(new TextAreaRenderer());

        // Renderer لزر الحذف في عمود Action
        eventsTable.getColumnModel().getColumn(9).setCellRenderer(new ButtonRenderer());

        // نحمّل البيانات
        loadEventsData();

        // نخفي عمود الـ ID من الـ VIEW (يبقى في الموديل)
        eventsTable.removeColumn(eventsTable.getColumnModel().getColumn(0));

        // Scroll
        JScrollPane scrollPane = new JScrollPane(eventsTable);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(scrollPane, BorderLayout.CENTER);

        // MouseListener للضغط على زر Delete
        eventsTable.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                int viewRow = eventsTable.rowAtPoint(e.getPoint());
                int viewCol = eventsTable.columnAtPoint(e.getPoint());
                if (viewRow < 0 || viewCol < 0) return;

                // نجيب modelIndex لعمود Action
                int actionModelIndex = eventsTable.getColumn("Action").getModelIndex();

                // لو اللي انضغط هو عمود Action
                if (viewCol == eventsTable.convertColumnIndexToView(actionModelIndex)) {
                    int modelRow = eventsTable.convertRowIndexToModel(viewRow);

                    int eventId = (int) tableModel.getValueAt(modelRow, 0);
                    String eventName = (String) tableModel.getValueAt(modelRow, 1);

                    int confirm = JOptionPane.showConfirmDialog(
                            EventsPanel.this,"Are you sure you want to delete the event \"" + eventName + "\"?",
                            "Confirm Deletion",
                            JOptionPane.YES_NO_OPTION
                    );

                    if (confirm == JOptionPane.YES_OPTION) {
                        boolean deleted = AdminService.deleteEventById(eventId);
                        if (deleted) {
                            tableModel.removeRow(modelRow);
                            JOptionPane.showMessageDialog(EventsPanel.this,
                                    "Event deleted.");
                        } else {
                            JOptionPane.showMessageDialog(EventsPanel.this,
                                    "Failed to delete event.",
                                    "Error",
                                    JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }
            }
        });
    }

    // تحميل البيانات + حساب Registrations و Most attended
    private void loadEventsData() {
        tableModel.setRowCount(0);

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT event_id, event_name, date, location, description, total_seats, availablity " +
                         "FROM events";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");

            // عدد التسجيلات لكل حدث
            Map<Integer, Integer> registrationsMap = AdminService.getRegistrationsPerEvent();
            int maxRegistrations = 0;
            for (int count : registrationsMap.values()) {
                if (count > maxRegistrations) {
                    maxRegistrations = count;
                }
            }

            while (rs.next()) {
                int id = rs.getInt("event_id");
                String name = rs.getString("event_name");
                Timestamp dateTS = rs.getTimestamp("date");
                String dateStr = (dateTS != null) ? sdf.format(dateTS) : "";
                String location = rs.getString("location");
                String description = rs.getString("description");
                int totalSeats = rs.getInt("total_seats");
                boolean available = rs.getBoolean("availablity");
                String availableStr = available ? "Yes" : "No";

                int registrations = registrationsMap.getOrDefault(id, 0);
                String mostAttended = (registrations == maxRegistrations && maxRegistrations > 0) ? "Yes" : "No";

                tableModel.addRow(new Object[]{
                        id,
                        name,
                        dateStr,
                        location,
                        description,
                        totalSeats,
                        registrations,
                        mostAttended,
                        availableStr,
                        "Delete"      // نص الزر
                });
            }

            rs.close();
            stmt.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "Error loading events from database:\n" + ex.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Renderer للوصف
    private static class TextAreaRenderer extends JTextArea implements TableCellRenderer {
        public TextAreaRenderer() {
            setLineWrap(true);
            setWrapStyleWord(true);
            setOpaque(true);
            setFont(new Font("Arial", Font.PLAIN, 14));
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                                                       boolean isSelected, boolean hasFocus,
                                                       int row, int column) {
            setText(value != null ? value.toString() : "");
            setSize(table.getColumnModel().getColumn(column).getWidth(),
                    getPreferredSize().height);

            if (isSelected) {
                setBackground(table.getSelectionBackground());
                setForeground(table.getSelectionForeground());
            } else {
                setBackground(table.getBackground());
                setForeground(table.getForeground());
            }

            return this;
        }
    }

    // Renderer لزر Delete
    private static class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
            setForeground(Color.RED);
            setBackground(Color.WHITE);
            setFont(new Font("Arial", Font.BOLD, 12));
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                                                       boolean isSelected,
                                                       boolean hasFocus,
                                                       int row, int column) {
            setText(value == null ? "Delete" : value.toString());
            return this;
        }
    }
}