package auth;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.sql.*;
import java.text.SimpleDateFormat;

import db.DBConnection;
import services.AdminService;

public class UsersPanel extends JPanel {
    private JLabel titleLabel;
    private JTable usersTable;
    private DefaultTableModel tableModel;
    private JButton editUserButton;
    private JButton deleteUserButton;

    public UsersPanel() {
        setLayout(new BorderLayout());

        // ===== العنوان في الأعلى =====
        titleLabel = new JLabel("Users", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(15, 0, 15, 0));
        add(titleLabel, BorderLayout.NORTH);

        // ===== تعريف الأعمدة للجدول =====
        String[] columnNames = {
                "User ID",
                "Username",
                "Email",
                "Role",
                "Gender",
                "Created At",
                "Updated At"
        };

        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // خليه read-only
            }
        };

        // ===== إنشاء الجدول =====
        usersTable = new JTable(tableModel);
        usersTable.setRowHeight(30);
        usersTable.setFont(new Font("Arial", Font.PLAIN, 14));
        usersTable.setFillsViewportHeight(true);
        usersTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

        // تنسيق الهيدر
        JTableHeader header = usersTable.getTableHeader();
        header.setFont(new Font("Arial", Font.BOLD, 14));
        header.setBackground(new Color(100, 100, 100));
        header.setForeground(Color.WHITE);
        header.setPreferredSize(new Dimension(header.getWidth(), 35));

        // ScrollPane
        JScrollPane scrollPane = new JScrollPane(usersTable);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(scrollPane, BorderLayout.CENTER);

        // ===== البوتوم بانل: أزرار Edit / Delete =====
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));

        editUserButton = new JButton("Edit Selected User");
        editUserButton.setFont(new Font("Arial", Font.BOLD, 14));
        editUserButton.addActionListener(e -> editSelectedUser());
        bottomPanel.add(editUserButton);

        deleteUserButton = new JButton("Delete Selected User");
        deleteUserButton.setFont(new Font("Arial", Font.BOLD, 14));
        deleteUserButton.addActionListener(e -> deleteSelectedUser());
        bottomPanel.add(deleteUserButton);

        add(bottomPanel, BorderLayout.SOUTH);

        // حمّل البيانات من الداتابيس
        loadUsersData();
    }

    // ================== تحميل المستخدمين من الداتابيس ==================
    private void loadUsersData() {
        tableModel.setRowCount(0); // تفريغ القديم

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "select user_id,username,password,email,role,gender,created_at,updated_at from users";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");

            while (rs.next()) {
                int userId = rs.getInt("user_id");
                String username = rs.getString("username");
                String email = rs.getString("email");
                String role = rs.getString("role");
                String gender = rs.getString("gender");
                Timestamp createdTS = rs.getTimestamp("created_at");
                String createdAt = (createdTS != null) ? sdf.format(createdTS) : "";
                Timestamp updatedTS = rs.getTimestamp("updated_at");
                String updatedAt = (updatedTS != null) ? sdf.format(updatedTS) : "";

                tableModel.addRow(new Object[]{userId, username, email, role, gender, createdAt, updatedAt
                });
            }

            rs.close();
            stmt.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "Error loading users from database:\n" + ex.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ================== تعديل المستخدم المختار ==================
    private void editSelectedUser() {
        int viewRow = usersTable.getSelectedRow();
        if (viewRow == -1) {
            JOptionPane.showMessageDialog(this,
                    "Please select a user first.",
                    "No Selection",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        int modelRow = usersTable.convertRowIndexToModel(viewRow);

        int userId = (int) tableModel.getValueAt(modelRow, 0);
        String currentUsername = (String) tableModel.getValueAt(modelRow, 1);
        String currentEmail = (String) tableModel.getValueAt(modelRow, 2);
        String currentRole = (String) tableModel.getValueAt(modelRow, 3);
        String currentGender = (String) tableModel.getValueAt(modelRow, 4);

        JTextField usernameField = new JTextField(currentUsername);
        JTextField emailField = new JTextField(currentEmail);

        JComboBox<String> roleBox = new JComboBox<>(new String[]{"attendee", "organizer"});
        if (currentRole != null) {
            roleBox.setSelectedItem(currentRole);
        }

        JComboBox<String> genderBox = new JComboBox<>(new String[]{"Male", "Female"});
        if (currentGender != null && !currentGender.isEmpty()) {
            genderBox.setSelectedItem(currentGender);
        }

        JPanel panel = new JPanel(new GridLayout(0, 1, 5, 5));
        panel.add(new JLabel("Username:"));
        panel.add(usernameField);
        panel.add(new JLabel("Email:"));
        panel.add(emailField);
        panel.add(new JLabel("Role:"));
        panel.add(roleBox);
        panel.add(new JLabel("Gender:"));
        panel.add(genderBox);

        int result = JOptionPane.showConfirmDialog(
                this,
                panel,
                "Edit User",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE
        );

        if (result == JOptionPane.OK_OPTION) {
            String newUsername = usernameField.getText().trim();
            String newEmail = emailField.getText().trim();
            String newRole = (String) roleBox.getSelectedItem();
            String newGender = (String) genderBox.getSelectedItem();

            if (newUsername.isEmpty() || newEmail.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Username and Email cannot be empty.",
                        "Validation Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            boolean ok = AdminService.updateUser(userId, newUsername, newEmail, newRole, newGender);
            if (ok) {
                JOptionPane.showMessageDialog(this,
                        "User updated successfully.",
                        "Success",
                        JOptionPane.INFORMATION_MESSAGE);
                loadUsersData(); // حدّث الجدول
            }
        }
    }

    // ================== حذف المستخدم المختار ==================
    private void deleteSelectedUser() {
        int viewRow = usersTable.getSelectedRow();
        if (viewRow == -1) {
            JOptionPane.showMessageDialog(this,
                    "Please select a user first.",
                    "No Selection",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        int modelRow = usersTable.convertRowIndexToModel(viewRow);
        int userId = (int) tableModel.getValueAt(modelRow, 0);
        String username = (String) tableModel.getValueAt(modelRow, 1);

        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete user \"" + username + "\"?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (confirm == JOptionPane.YES_OPTION) {
            boolean ok = AdminService.deleteUser(userId);
            if (ok) {
                JOptionPane.showMessageDialog(this,
                        "User deleted successfully.",
                        "Success",
                        JOptionPane.INFORMATION_MESSAGE);
                loadUsersData();
            }
            // لو صار FK error أو غيره، MessageBox في AdminService بيطلع الرسالة
        }
    }
}